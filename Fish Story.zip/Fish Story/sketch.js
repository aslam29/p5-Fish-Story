let index = 0; //  for function 8
let x1 = 0;
let x2 = 500;
let x3 = 1000;
let x4 = 1500;
let x5 = 2000;
let x6 = 2500;

function preload() {
  image1 = createImg('https://alvinlam.yolasite.com/resources/Fish%201%20D.png.opt940x940o0%2C0s940x940.png');
  image2 = createImg('https://alvinlam.yolasite.com/resources/Fish%202%20D.png.opt940x940o0%2C0s940x940.png');
  image3 = createImg('https://alvinlam.yolasite.com/resources/Fish%203%20D.png.opt940x940o0%2C0s940x940.png');
  image4 = createImg('https://alvinlam.yolasite.com/resources/Fish%204%20D.png.opt940x940o0%2C0s940x940.png');
  image5 = createImg('https://alvinlam.yolasite.com/resources/Fish%205%20D.png.opt940x940o0%2C0s940x940.png');
  image6 = createImg('https://alvinlam.yolasite.com/resources/Fish%206%20D.png.opt940x940o0%2C0s940x940.png');
}

function setup() {
  createCanvas(500, 500);

  test = new Platform(image1, image2, image3, image4, image5, image6);
}

function draw() {
  background(222);

  test.function9();
}

class Platform {
  constructor() {
    this.x = 0;     // offset position that will affect all the images
    this.speed = 3.32; // how fast you want something to move, depends on your implementation  // used for function6

    this.arr = [image1, image2, image3, image4, image5, image6];
    print("Length is: " + this.arr.length);
  }

  // Format: image(this.array[index], x, y, width, height);
  
    function9() {

    image(this.arr[index], 0, 0, width, height);
  }
}

// for function9 currently
function mousePressed() {
  // for function9
  index++;

  // reset the index
  if (index > 5) {
    index = 0;
  }
}
